#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <time.h>
#include <string.h>
#include <stdbool.h>
#define MAX_VALUE 10000



/**
 * @brief This function makes it possible to populate an array of integers randomly, with values between zero and the macro defined with MAX_VALUE
 * 
 * @param n the length of the array to be populated
 * @param seed integer value to be used as seed by the pseudo-random number generator algorithm
 * @param array the reference to the array to be populated
 */
void generateArray( int n, int seed, int* array){
    srand(seed);
    for (int i = 0; i < n; i++) 
        array[i] =(int)rand() % MAX_VALUE;
}

int main(int argc, char **argv)
{
    int world_rank, world_size;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    int* arr, *output;
    int*count = (int *)calloc(MAX_VALUE + 1, sizeof(int));

    MPI_Status status;
    double generateArray_start_time;
    double generateArray_end_time;
    // countingSort_end_time coincides with the value taken by generateArray_end_time 
    double countingSort_end_time;

    if (argc < 2)
    {
        if (world_rank == 0)
            printf("ERROR! Usage: ./main ARRAY_LENGTH ");
        MPI_Finalize();
        exit(EXIT_FAILURE);
    }
    int n = atoi(argv[1]); 
    arr = (int*)malloc(sizeof(int)*n);

    //the length of the array is divided equally for each process, if it is not divisible, the residue of the division is assigned to rank 0
    int size = n / world_size;
    if(world_rank == 0) 
        size += n % world_size;

    int* local_array = (int*) malloc(size*sizeof(int));
    int* local_count = (int*) calloc(MAX_VALUE+1, sizeof(int));

    //every process generates its array locally
    MPI_Barrier(MPI_COMM_WORLD);
    generateArray_start_time = MPI_Wtime(); 
    generateArray(size, world_rank, local_array);     
    MPI_Barrier(MPI_COMM_WORLD);


    if(world_rank==0){
        //collects every local array and stores it into arr which represents the global array
        int *disps=(int*)malloc(world_size*sizeof(int));
        int *counts_recv=(int*)malloc(world_size*sizeof(int));

        disps[0] = 0;
        counts_recv[0] = n/world_size + n%world_size;

        for (int i=1; i<world_size;i++){
            disps[i] = n%world_size + (i*(n/world_size));
            counts_recv[i] = n/world_size;
        }

        MPI_Gatherv(local_array, size, MPI_INT, arr,counts_recv,disps, MPI_INT,0,MPI_COMM_WORLD);

        free(disps);
        free(counts_recv);
    }
    else{
        //every array sends its chunck of data to the root represented by rank 0
        MPI_Gatherv(local_array, size, MPI_INT, NULL,NULL,NULL, MPI_INT,0,MPI_COMM_WORLD);
    }
    
    MPI_Barrier(MPI_COMM_WORLD);
    generateArray_end_time = MPI_Wtime();
    
    // beginning of counting sort

    for (int i = 0; i < size; i++){
        local_count[local_array[i]]++;
    }      
    
    for (int i = 1; i <= MAX_VALUE; i++)
        local_count[i] += local_count[i - 1];


    MPI_Reduce(local_count,count,MAX_VALUE+1,MPI_INT, MPI_SUM,0,MPI_COMM_WORLD);

   
    //sequential part to generate the final sorted array 
    if(world_rank ==0){
    
        output = (int *)calloc(n, sizeof(int));
        for (int i = 0; i < n; i++)
        {
            output[count[arr[i]] - 1] = arr[i];
            count[arr[i]]--;
        }
    }

    MPI_Barrier(MPI_COMM_WORLD);
    countingSort_end_time = MPI_Wtime();
    
        

    if(world_rank == 0){
        
        double generateArray_time = generateArray_end_time - generateArray_start_time;
        double countingSort_time =  countingSort_end_time - generateArray_end_time;
        
        double elapsed = countingSort_time + generateArray_time;
        printf("%d,%d,%f,%f,%f\n", n, world_size, generateArray_time, countingSort_time, elapsed);
        
        free(output);
    }

    free(count);
    free(arr);    
    free(local_array);
    free(local_count);
    MPI_Finalize();
    return 0;
}
