
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <time.h>



int main(int argc, char  *argv[])
{
    int world_rank, world_size;

    int dimArray=100000000;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);
    MPI_Status status;
    srand(time(NULL)); 

    int chunck;
    if(world_rank != world_size-1)
        chunck = dimArray / (world_size-1);
    else
        chunck = dimArray % (world_size-1);
    
	int displacement = world_rank * chunck;

    int *arr = (int*)malloc(chunck*sizeof(int));
    MPI_File fp, fw;

    if(world_rank==0){

        MPI_File_open(MPI_COMM_SELF, "init.bin", MPI_MODE_CREATE | MPI_MODE_WRONLY, MPI_INFO_NULL, &fw);

        int *arr2 = (int*)malloc(dimArray*sizeof(int));

        for(int i=0;i<dimArray;i++)
            arr2[i] =(int)rand()%10000;

        MPI_File_write(fw, arr2, dimArray, MPI_INT,MPI_STATUS_IGNORE);

       /* for(int i=0;i<dimArray;i++)
            printf("%d  ", arr2[i]);*/
    
        free(arr2);
    }
    


    MPI_File_open(MPI_COMM_WORLD, "init.bin", MPI_MODE_CREATE | MPI_MODE_RDWR, MPI_INFO_NULL, &fp);

	
    if(world_rank != world_size-1)
        MPI_File_seek(fp, sizeof(int)*displacement, MPI_SEEK_SET);
    else
        MPI_File_seek(fp,sizeof(int)* (dimArray - dimArray%(world_size-1)), MPI_SEEK_SET);
    
    MPI_File_read_all(fp, arr, chunck, MPI_INT, MPI_STATUS_IGNORE);   
    //printf("\n------\n");


    /*for(int i=0;i<chunck;++i){
        printf("%d  ", arr[i]);
    }
	*/
    


    free(arr);
    MPI_Finalize();
    return 0;
}
