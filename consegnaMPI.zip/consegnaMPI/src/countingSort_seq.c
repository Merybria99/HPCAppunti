/*
#
# Course: High Performance Computing 2021/2022
# 
# Lecturer: Francesco Moscato    fmoscato@unisa.it
#
# Group:
# Briglia Maria Rosaria        0622701711    m.briglia1@studenti.unisa.it
# Della Monica Pierpaolo    0622701701  p.dellamonica9@studenti.unisa.it 
# Giannino Pio Roberto        0622701713  p.giannino@studenti.unisa.it
#
# This file is part of SecondProjectMPI.
#
# SecondProjectMPI is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Requirements: Parallelize and Evaluate Performances of "COUNTING SORT" Algorithm ,by using MPI.
# 
# To produce this analysis files produced by previous years group 02 have been used.
#
# SecondProjectMPI is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with SecondProjectMPI.  If not, see http://www.gnu.org/licenses/.
#*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/times.h>

void generateArray(int arr[], int dim);
int getMax(int *arr, int n);
void countingSort(int A[], int C[], int length, int k);

int main(int argc, char const *argv[])
{
    if (argc < 2)
    {
        printf("ERROR! Usage: ./main dimarray ");
        exit(1);
    }
    int dimArray = atoi(argv[1]); //write the dimension of array

    int *arr = (int *)calloc(dimArray, sizeof(int));
    int *output = (int *)calloc(dimArray, sizeof(int));

    
    struct tms generateArray_start_times;
    clock_t generateArray_start_etime;
    generateArray_start_etime = times(&generateArray_start_times);

    generateArray(arr, dimArray); 

    struct tms generateArray_end_times;
    clock_t generateArray_end_etime;
    generateArray_end_etime = times(&generateArray_end_times);
    

    int k = getMax(arr, dimArray);

    
    struct tms countingSort_start_times;
    clock_t countingSort_start_etime;
    countingSort_start_etime = times(&countingSort_start_times);

    countingSort(arr, output, dimArray, k);

    struct tms countingSort_end_times;
    clock_t countingSort_end_etime;
    countingSort_end_etime = times(&countingSort_end_times);
   


    // Get clock ticks per sec
    long clktck = 0;
    if ((clktck = sysconf(_SC_CLK_TCK)) < 0)
    {
        fprintf(stderr, "ERROR: filed to get slock ticks per sec\n");
        exit(EXIT_FAILURE);
    }

    double generateArray_elapsed = (generateArray_end_etime - generateArray_start_etime) / (double)clktck;
    double countingSort_elapsed = (countingSort_end_etime - countingSort_start_etime) / (double)clktck;

    double elapsed = countingSort_elapsed + generateArray_elapsed;

    printf("%d,0,%f,%f,%f\n", dimArray, generateArray_elapsed, countingSort_elapsed, elapsed);

    free(arr);
    free(output);
    return 0;
}

/**
 * @brief This function implements counting sort in serial fashion, based on the pseudo-code provided by wikipedia.
 *
 * @param arr represents the input array to be sorted
 * @param output represents the output array as a result of the sorting process.
 * @param length the number of elements in the input array.
 * @param k the maximum value that can be found within the input array, this is used to construct the respective count array.
 */
void countingSort(int arr[], int output[], int length, int k)
{
    int *count = (int *)calloc(k + 1, sizeof(int));
    for (int i = 0; i <= length - 1; i++)
        count[arr[i]] += 1;

    for (int i = 1; i <= k; i++)
        count[i] += count[i - 1];

    for (int i = length - 1; i >= 0; i--)
    {
        output[count[arr[i]] - 1] = arr[i];
        count[arr[i]]--;
    }
    free(count);
}


/**
 * @brief Get the Max value from the array
 *
 * @param arr   array that we want calculate the maximum element
 * @param n     dimension of array
 * @return int  return the max element of array
 */
int getMax(int *arr, int n){
    int max = arr[0];
    for (int i = 0; i < n; i++)
        if (arr[i] > max)
            max = arr[i];
    return max;
}


/**
 * @brief This function makes it possible to populate an array of integers randomly, with values between zero and 100000
 * 
 * @param dim the length of the array to be populated
 * @param arr the reference to the array to be populated
 */
void generateArray(int arr[], int dim){
    unsigned int seed = time(NULL);
    for (int i = 0; i < dim; i++)
        arr[i] = rand_r(&seed) % 100000;
}