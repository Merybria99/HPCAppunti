/*
#
# Course: High Performance Computing 2021/2022
# 
# Lecturer: Francesco Moscato    fmoscato@unisa.it
#
# Group:
# Briglia Maria Rosaria        0622701711    m.briglia1@studenti.unisa.it
# Della Monica Pierpaolo    0622701701  p.dellamonica9@studenti.unisa.it 
# Giannino Pio Roberto        0622701713  p.giannino@studenti.unisa.it
#
# This file is part of SecondProjectMPI.
#
# SecondProjectMPI is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Requirements: Parallelize and Evaluate Performances of "COUNTING SORT" Algorithm ,by using MPI.
# 
# To produce this analysis files produced by previous years group 02 have been used.
#
# SecondProjectMPI is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with SecondProjectMPI.  If not, see http://www.gnu.org/licenses/.
#*/

#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <time.h>
#define MAX_VALUE 10000


int main(int argc, char **argv)
{
    int world_rank, world_size;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    MPI_Status status;
    double generateArray_start_time ;
    double generateArray_end_time;
    double countingSort_end_time=0;

    if (argc < 2)
    {
        if (world_rank == 0)
            printf("ERROR! Usage: ./main dimarray ");
        MPI_Finalize();
        exit(EXIT_FAILURE);
    }

    int dimArray = atoi(argv[1]); //write the dimension of array
    int*arr = (int*)malloc(sizeof(int)*dimArray);

    MPI_File fp;
    MPI_File_open(MPI_COMM_WORLD, "../src/init.bin", MPI_MODE_CREATE | MPI_MODE_RDWR, MPI_INFO_NULL, &fp);
    int chunck;

    int *arrlocal;
    int*count = (int*) calloc(MAX_VALUE + 1, sizeof(int));
    int* local_count = (int*) calloc(MAX_VALUE + 1, sizeof(int));
 

    if(world_rank == 0){
        chunck = dimArray % (world_size) + dimArray / world_size;
        int displacement = dimArray - chunck;

        arrlocal = (int*)malloc(chunck*sizeof(int));

        MPI_File_seek(fp, sizeof(int)*displacement, MPI_SEEK_SET);
    }
    else{
        chunck = dimArray / (world_size);
        int displacement = (world_rank-1)* chunck;

        arrlocal = (int*)malloc(chunck*sizeof(int));
        
        MPI_File_seek(fp,sizeof(int)*displacement, MPI_SEEK_SET);
    }
    

    MPI_Barrier(MPI_COMM_WORLD);
    generateArray_start_time = MPI_Wtime();
    MPI_File_read_all(fp, arrlocal, chunck, MPI_INT, MPI_STATUS_IGNORE);   

    

    if(world_rank==0){
        //collects every local array and stores it into arr
        int *disps=(int*)malloc(world_size*sizeof(int));
        int *counts_recv=(int*)malloc(world_size*sizeof(int));

        disps[0] = 0;
        counts_recv[0] = dimArray/world_size+dimArray%world_size;

        for (int i=1; i<world_size;i++){
            disps[i]= dimArray%world_size + (i*(dimArray/world_size));
            counts_recv[i]=dimArray/world_size;
        }
        
        MPI_Gatherv(arrlocal, chunck, MPI_INT, arr,counts_recv,disps, MPI_INT,0,MPI_COMM_WORLD);

        free(disps);
        free(counts_recv);
        
    }
    else{
        //every array sends its chunck of data to the root
        MPI_Gatherv(arrlocal, chunck, MPI_INT, NULL,NULL,NULL, MPI_INT,0,MPI_COMM_WORLD);
    }

    MPI_Barrier(MPI_COMM_WORLD);
    generateArray_end_time = MPI_Wtime();

    
  
    for (int i = 0; i < chunck; i++){
        local_count[arrlocal[i]]++;
    }      
    
    for (int i = 1; i <= MAX_VALUE; i++)
        local_count[i] += local_count[i - 1];


    MPI_Allreduce(local_count,count,MAX_VALUE+1,MPI_INT, MPI_SUM,MPI_COMM_WORLD);
    
    int count_size= MAX_VALUE/world_size;
    if (world_rank==(world_size-1)) count_size+=MAX_VALUE%world_size;

    int offset = (world_rank*(MAX_VALUE/world_size));
    int length = count[offset+count_size]-count[offset];

    int* local_output = (int*)malloc(sizeof(int)*(count[offset+count_size]-count[offset]));
    int index = 0;


    for(int i=offset+1 ;i<=offset+count_size;i++){
        int increment = count[i]-count[i-1];
        if (increment != 0){
            for(int j=0;j<increment;j++, index++){
                local_output[index] = i;
            }
        }
    }
    MPI_Barrier(MPI_COMM_WORLD);
    countingSort_end_time = MPI_Wtime();
    
      
    
    MPI_File fw;
    MPI_File_open(MPI_COMM_SELF, "../src/sorted.bin", MPI_MODE_CREATE | MPI_MODE_RDWR, MPI_INFO_NULL, &fw);
    MPI_Barrier(MPI_COMM_WORLD);

    if(world_rank==0)
        MPI_File_seek(fw, 0, MPI_SEEK_SET);
    else
        MPI_File_seek(fw, count[offset]*sizeof(int), MPI_SEEK_SET);
    
        
    double writeArray_start_time = MPI_Wtime();
    MPI_File_write(fw, local_output, length, MPI_INT,MPI_STATUS_IGNORE);
    MPI_Barrier(MPI_COMM_WORLD);
    double writeArray_end_time = MPI_Wtime();
    MPI_File_close(&fw);
    if(world_rank==0){
        
        double read_and_write_Array_time = generateArray_end_time - generateArray_start_time + writeArray_end_time - writeArray_start_time;
        double countingSort_time = countingSort_end_time - generateArray_end_time;

        double elapsed = read_and_write_Array_time + countingSort_time;
        printf("%d,%d,%f,%f,%f\n", dimArray, world_size, read_and_write_Array_time, countingSort_time, elapsed);
    }

    free(arrlocal);
    MPI_File_close(&fp);
    
    MPI_Finalize();
    return 0;
}
