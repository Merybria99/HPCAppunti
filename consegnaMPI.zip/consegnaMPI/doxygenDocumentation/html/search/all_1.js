var searchData=
[
  ['generatearray_6',['generateArray',['../d8/dec/countingSort__MPI_8c.html#ab2aea84287bf65b19859aa9dbe0a7257',1,'generateArray(int n, int seed, int *array):&#160;countingSort_MPI.c'],['../d8/d8f/countingSort__MPIFullParallel_8c.html#ab2aea84287bf65b19859aa9dbe0a7257',1,'generateArray(int n, int seed, int *array):&#160;countingSort_MPIFullParallel.c'],['../d8/dc9/countingSort__MPIFullParallel2_8c.html#ab2aea84287bf65b19859aa9dbe0a7257',1,'generateArray(int n, int seed, int *array):&#160;countingSort_MPIFullParallel2.c'],['../d4/df1/countingSort__seq_8c.html#a0ddb38c161d1ddc52a4fd278d4df2d34',1,'generateArray(int arr[], int dim):&#160;countingSort_seq.c']]],
  ['getmax_7',['getMax',['../d4/df1/countingSort__seq_8c.html#a6ea4f333d5ce7852b1ba236bdad4917d',1,'countingSort_seq.c']]]
];
