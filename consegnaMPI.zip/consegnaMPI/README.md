# SecondProjectMPI

## Dependencies

* CMake 3.9+
* OpenMPI
* Python3 3.9.7
* Pipenv

## How to run

Before running the execution make sure that you have the permission as administrator to run the example. To prevent
possible errors it has been insert a command that gives right permissions to run the code properly.

1. Extract the folder and then run the following commands:

   ```batch
   chmod 777 -R *
   mkdir build
   cd build
   cmake ..
   ```

2. Generate executables with `make`
3. To generate measures run
    - `make generate_measures` to run the execution of the first case of study
    - `make generate_measures2` to run the execution of the second case of study
    - `make generate_measures3` to run the execution of the third case of study
    - to run the execution of the fourth case of study
         ```bash
            cd ../src
            mpicc initRint.c -o initializeFile
            mpirun -np processes_numbers ./initializeFile

            #the generation of the file will take a while

            cd ../build 
        ```
        `make generate_measures_rw`
  
4. To extract graphics and tables for speedup and efficiency from the .csv files run
    - `make extract_measures` to run the extraction of the first case of study
    - `make extract_measures2` to run the extraction of the second case of study
    - `make extract_measures3` to run the extraction of the third case of study
    - `make extract_measures_rw` to run the extraction of the fourth case of study

Results can be found in the `measures/measure`, `measures/measure2`,`measures/measure3`  or `measures/measure_rw` directory, divided by problem size and the gcc
optimization option used.


