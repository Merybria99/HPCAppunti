/*
#
# Course: High Performance Computing 2021/2022
# 
# Lecturer: Francesco Moscato    fmoscato@unisa.it
#
# Group:
# Briglia Maria Rosaria        0622701711    m.briglia1@studenti.unisa.it
# Della Monica Pierpaolo    0622701701  p.dellamonica9@studenti.unisa.it 
# Giannino Pio Roberto        0622701713  p.giannino@studenti.unisa.it
#
# This file is part of SecondProjectMPI.
#
# SecondProjectMPI is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# Requirements: Parallelize and Evaluate Performances of "COUNTING SORT" Algorithm ,by using MPI.
# 
# To produce this analysis files produced by previous years group 02 have been used.
#
# SecondProjectMPI is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with SecondProjectMPI.  If not, see http://www.gnu.org/licenses/.
#*/

/**
	@file test.c
*/

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#define LENGTH 100
#define MAX_VALUE 10000

void countingSort(int arr[], int output[], int length, int k);

int main(int argc, char *argv[])
{
	int* array = (int *)malloc(LENGTH*sizeof(int));
	int* sorted = (int *)malloc(LENGTH*sizeof(int));
	int* sortedMPI = (int *)malloc(LENGTH*sizeof(int));
	int res = 0, count =0;
	FILE *fd;

	fd=fopen("../src/initTest.bin", "r");
	if( fd==NULL ) {
		fprintf(stderr,"Error in opening the file");
		exit(1);
	}

	
	res=fread(&array[count++], sizeof(int), 1, fd);
	while(res ==1 && count<LENGTH){
		res=fread(&array[count], sizeof(int), 1, fd);
		count++;
	}
	if( res!=1 ) {
		fprintf(stderr,"Error in reading the file");
		exit(1);
	}


	countingSort(array, sorted, LENGTH, MAX_VALUE);
	fd=fopen("../src/sortedTest.bin", "r");
	if( fd==NULL ) {
		fprintf(stderr,"Error in opening the file2");
		exit(1);
	}
	


	count = 0;
	res=fread(&sortedMPI[count++], sizeof(int), 1, fd);
	while(res ==1 && count<LENGTH){
		res=fread(&sortedMPI[count], sizeof(int), 1, fd);
		count++;
	}
	if( res!=1) {
		fprintf(stderr,"Error in reading the file2");
		exit(1);
	}

	fclose(fd);



	for(int i =0;i<LENGTH;i++){
		if(sorted[i]!=sortedMPI[i]){
			fprintf(stderr, "\nError found at index %d, expected %d, actual %d\n", i,  sorted[i], sortedMPI[i]);
			exit(EXIT_FAILURE);
		}
	}
	printf("Test done\n");
	exit(EXIT_SUCCESS);
}


/**
 * @brief This function implements counting sort in serial fashion, based on the pseudo-code provided by wikipedia.
 *
 * @param arr represents the input array to be sorted
 * @param output represents the output array as a result of the sorting process.
 * @param length the number of elements in the input array.
 * @param k the maximum value that can be found within the input array, this is used to construct the respective count array.
 */
void countingSort(int arr[], int output[], int length, int k)
{
    int *count = (int *)calloc(k + 1, sizeof(int));
    for (int i = 0; i <= length - 1; i++)
        count[arr[i]] += 1;

    for (int i = 1; i <= k; i++)
        count[i] += count[i - 1];

    for (int i = length - 1; i >= 0; i--)
    {
        output[count[arr[i]] - 1] = arr[i];
        count[arr[i]]--;
    }
    free(count);
}
