var indexSectionsWithContent =
    {
        0: "cegmos",
        1: "cm",
        2: "cgm",
        3: "eos"
    };

var indexSectionNames =
    {
        0: "all",
        1: "files",
        2: "functions",
        3: "defines"
    };

var indexSectionLabels =
    {
        0: "All",
        1: "Files",
        2: "Functions",
        3: "Macros"
    };

