var searchData =
    [
        ['omp_5fget_5fthread_5fnum_20', ['omp_get_thread_num', ['../de/d89/countingsort_8c.html#a889ec205c635b219999c761b28cc39ba', 1, 'countingsort.c']]]
    ];
